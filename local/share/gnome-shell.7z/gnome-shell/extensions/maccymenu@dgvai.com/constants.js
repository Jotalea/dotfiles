var ICONS = [
  {
    idx: 0,
    title: "Apple",
    path: "/resources/icons/apple.svg",
  },
  {
    idx: 1,
    title: "Ubuntu",
    path: "/resources/icons/ubuntu.svg",
  },
  {
    idx: 2,
    title: "Fedora",
    path: "/resources/icons/fedora.svg",
  },
  {
    idx: 3,
    title: "Linux",
    path: "/resources/icons/linux.svg",
  },
  {
    idx: 4,
    title: "Debian",
    path: "/resources/icons/debian.svg",
  },
  {
    idx: 5,
    title: "Arch",
    path: "/resources/icons/arch.svg",
  },
  {
    idx: 6,
    title: "Kali",
    path: "/resources/icons/kali.svg",
  },
];
