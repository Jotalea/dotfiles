# Maccy Menu
[<img src="https://github.com/andyholmes/gnome-shell-extensions-badge/raw/master/get-it-on-ego.png">](https://extensions.gnome.org/extension/6021/maccy-menu/)

### Screenshot Preview
![MaccyMenu Preview](./docs/imgs/preview.png)

### Installation
You can install this extension by:
- Install from [GNOME Extensions](https://extensions.gnome.org/extension/6021/maccy-menu/) hub.
- or Search for **Maccy Menu** in GNOME Shell Extension Desktop Application.
